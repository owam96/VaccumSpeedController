var searchData=
[
  ['realloc_72',['realloc',['../unity__memory_8h.html#a1b739878adcdb46fb5d209af7ce79628',1,'unity_memory.h']]],
  ['released_73',['RELEASED',['../switches_8h.html#add2c37d13e3ac54d516471310b237ac7aa38d18fe73a7fc82c112b6917d0b5cd0',1,'switches.h']]],
  ['repeatcount_74',['RepeatCount',['../struct_u_n_i_t_y___f_i_x_t_u_r_e___t.html#a08f81baf4504c4cbb9eafc2e4f89324a',1,'UNITY_FIXTURE_T']]],
  ['resettest_75',['resetTest',['../unity_8h.html#afb3a9b98e779c4f69e72aca5aa9fa1d7',1,'unity.h']]],
  ['return_5fif_5ffail_5for_5fignore_76',['RETURN_IF_FAIL_OR_IGNORE',['../unity_8c.html#abf9f99b384602e58874744dda3492aaa',1,'unity.c']]],
  ['run_5ftest_77',['RUN_TEST',['../unity__internals_8h.html#a27cf08abbe33174b41d808a147cfef11',1,'unity_internals.h']]],
  ['run_5ftest_5fcase_78',['RUN_TEST_CASE',['../unity__fixture_8h.html#adc2b732a34781cebd1432e413f4ccfbc',1,'unity_fixture.h']]],
  ['run_5ftest_5fgroup_79',['RUN_TEST_GROUP',['../unity__fixture_8h.html#a7fc679775ab3aaf4dd7302a0a4118202',1,'unity_fixture.h']]],
  ['runalltests_80',['RunAllTests',['../main_8c.html#a681847cb468289c483c1f110b251f91c',1,'main.c']]],
  ['running_81',['RUNNING',['../timer_8h.html#a612d4bf9b0bc3c283ec2a4a16762c4b1a1061be6c3fb88d32829cba6f6b2be304',1,'timer.h']]]
];
