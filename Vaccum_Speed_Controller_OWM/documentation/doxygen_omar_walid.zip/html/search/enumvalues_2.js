var searchData=
[
  ['neg_1046',['NEG',['../switches_8h.html#a6fb694a794c8aad66c29742b898cf760af6ac87750a3d0fb390234808731fd4b3',1,'switches.h']]]
];
