var searchData=
[
  ['setup_921',['setUp',['../unity_8h.html#a95c834d6178047ce9e1bce7cbfea2836',1,'setUp(void):&#160;unity_fixture.c'],['../unity__fixture_8c.html#a95c834d6178047ce9e1bce7cbfea2836',1,'setUp(void):&#160;unity_fixture.c']]],
  ['speed_5fcontroller_5fget_5fspeed_922',['SPEED_CONTROLLER_get_speed',['../speed__controller_8c.html#a44f67dbd613a0f2022d15dd70c2ca6ea',1,'SPEED_CONTROLLER_get_speed():&#160;speed_controller.c'],['../speed__controller_8h.html#a44f67dbd613a0f2022d15dd70c2ca6ea',1,'SPEED_CONTROLLER_get_speed():&#160;speed_controller.c']]],
  ['speed_5fcontroller_5fgettestdata_923',['SPEED_CONTROLLER_getTestData',['../speed__controller__test_8c.html#af2d06ac16eb100ca944b61d51c56165c',1,'SPEED_CONTROLLER_getTestData(int test_num):&#160;speed_controller_test.c'],['../speed__controller__test_8h.html#a2ccc19fe218f0c11ddb9871f37dbd116',1,'SPEED_CONTROLLER_getTestData(int):&#160;speed_controller_test.c']]],
  ['speed_5fcontroller_5finit_924',['SPEED_CONTROLLER_init',['../speed__controller_8c.html#ac089cc6e5b0da52e843ce9f73238fe41',1,'SPEED_CONTROLLER_init():&#160;speed_controller.c'],['../speed__controller_8h.html#ac089cc6e5b0da52e843ce9f73238fe41',1,'SPEED_CONTROLLER_init():&#160;speed_controller.c']]],
  ['speed_5fcontroller_5fset_5fspeed_925',['SPEED_CONTROLLER_set_speed',['../speed__controller_8c.html#acc39418270d8196447bce937aaf64379',1,'SPEED_CONTROLLER_set_speed(SPEED_t given_speed):&#160;speed_controller.c'],['../speed__controller_8h.html#a061e0f3733400f69cb1fa8d01e4b4c89',1,'SPEED_CONTROLLER_set_speed(SPEED_t):&#160;speed_controller.c']]],
  ['speed_5fcontroller_5fstring_5fto_5fenum_926',['SPEED_CONTROLLER_string_to_enum',['../speed__controller__test_8c.html#a2b6126496d86370b533aa361dead30e0',1,'speed_controller_test.c']]],
  ['suitesetup_927',['suiteSetUp',['../unity_8h.html#a0f08bc53b5978d3892a36f98df005b37',1,'unity.h']]],
  ['suiteteardown_928',['suiteTearDown',['../unity_8h.html#a3eac1f0f22f9093d82efeed457a1b1d3',1,'unity.h']]]
];
