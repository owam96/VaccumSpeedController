var searchData=
[
  ['off_62',['OFF',['../timer_8h.html#a612d4bf9b0bc3c283ec2a4a16762c4b1aac132f2982b98bcaa3445e535a03ff75',1,'timer.h']]],
  ['old_5fvalue_63',['old_value',['../struct_pointer_pair.html#a22eefe5979d9ff822eccf52dc57be1e8',1,'PointerPair']]]
];
