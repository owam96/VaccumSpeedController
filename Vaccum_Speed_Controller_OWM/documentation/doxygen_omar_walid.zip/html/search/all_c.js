var searchData=
[
  ['setup_82',['setUp',['../unity_8h.html#a95c834d6178047ce9e1bce7cbfea2836',1,'setUp(void):&#160;unity_fixture.c'],['../unity__fixture_8c.html#a95c834d6178047ce9e1bce7cbfea2836',1,'setUp(void):&#160;unity_fixture.c']]],
  ['silent_83',['Silent',['../struct_u_n_i_t_y___f_i_x_t_u_r_e___t.html#a545e00f43de20ca1e6b98e226030f0ad',1,'UNITY_FIXTURE_T']]],
  ['size_84',['size',['../struct_guard_bytes.html#a854352f53b148adc24983a58a1866d66',1,'GuardBytes']]],
  ['speed_5fcontroller_2ec_85',['speed_controller.c',['../speed__controller_8c.html',1,'']]],
  ['speed_5fcontroller_2eh_86',['speed_controller.h',['../speed__controller_8h.html',1,'']]],
  ['speed_5fcontroller_5fget_5fspeed_87',['SPEED_CONTROLLER_get_speed',['../speed__controller_8c.html#a44f67dbd613a0f2022d15dd70c2ca6ea',1,'SPEED_CONTROLLER_get_speed():&#160;speed_controller.c'],['../speed__controller_8h.html#a44f67dbd613a0f2022d15dd70c2ca6ea',1,'SPEED_CONTROLLER_get_speed():&#160;speed_controller.c']]],
  ['speed_5fcontroller_5fgettestdata_88',['SPEED_CONTROLLER_getTestData',['../speed__controller__test_8c.html#af2d06ac16eb100ca944b61d51c56165c',1,'SPEED_CONTROLLER_getTestData(int test_num):&#160;speed_controller_test.c'],['../speed__controller__test_8h.html#a2ccc19fe218f0c11ddb9871f37dbd116',1,'SPEED_CONTROLLER_getTestData(int):&#160;speed_controller_test.c']]],
  ['speed_5fcontroller_5finit_89',['SPEED_CONTROLLER_init',['../speed__controller_8c.html#ac089cc6e5b0da52e843ce9f73238fe41',1,'SPEED_CONTROLLER_init():&#160;speed_controller.c'],['../speed__controller_8h.html#ac089cc6e5b0da52e843ce9f73238fe41',1,'SPEED_CONTROLLER_init():&#160;speed_controller.c']]],
  ['speed_5fcontroller_5fset_5fspeed_90',['SPEED_CONTROLLER_set_speed',['../speed__controller_8c.html#acc39418270d8196447bce937aaf64379',1,'SPEED_CONTROLLER_set_speed(SPEED_t given_speed):&#160;speed_controller.c'],['../speed__controller_8h.html#a061e0f3733400f69cb1fa8d01e4b4c89',1,'SPEED_CONTROLLER_set_speed(SPEED_t):&#160;speed_controller.c']]],
  ['speed_5fcontroller_5fstring_5fto_5fenum_91',['SPEED_CONTROLLER_string_to_enum',['../speed__controller__test_8c.html#a2b6126496d86370b533aa361dead30e0',1,'speed_controller_test.c']]],
  ['speed_5fcontroller_5ftest_2ec_92',['speed_controller_test.c',['../speed__controller__test_8c.html',1,'']]],
  ['speed_5fcontroller_5ftest_2eh_93',['speed_controller_test.h',['../speed__controller__test_8h.html',1,'']]],
  ['speed_5ft_94',['SPEED_t',['../speed__controller_8h.html#a3a3e647cd9794069781fd06324b978d5',1,'speed_controller.h']]],
  ['strcmp_5fequal_95',['STRCMP_EQUAL',['../unity__fixture_8h.html#ade1dda09c948fee9ceb853bc6dd5f3cb',1,'unity_fixture.h']]],
  ['suitesetup_96',['suiteSetUp',['../unity_8h.html#a0f08bc53b5978d3892a36f98df005b37',1,'unity.h']]],
  ['suiteteardown_97',['suiteTearDown',['../unity_8h.html#a3eac1f0f22f9093d82efeed457a1b1d3',1,'unity.h']]],
  ['switch_5fstate_5ft_98',['SWITCH_STATE_t',['../switches_8h.html#add2c37d13e3ac54d516471310b237ac7',1,'switches.h']]],
  ['switch_5ftype_5ft_99',['SWITCH_TYPE_t',['../switches_8h.html#a6fb694a794c8aad66c29742b898cf760',1,'switches.h']]],
  ['switches_2ec_100',['switches.c',['../switches_8c.html',1,'']]],
  ['switches_2eh_101',['switches.h',['../switches_8h.html',1,'']]]
];
