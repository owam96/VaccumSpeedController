var searchData=
[
  ['make_5funity_5fverbose_1098',['MAKE_UNITY_VERBOSE',['../main_8c.html#ad149babada47f3151ca626d534974ef1',1,'main.c']]],
  ['malloc_1099',['malloc',['../unity__memory_8h.html#acf143577800376dd931c059ecc61ba06',1,'unity_memory.h']]],
  ['malloc_5fdont_5ffail_1100',['MALLOC_DONT_FAIL',['../unity__memory_8c.html#a3f1b1eff9064dbe426821f93e435fee5',1,'unity_memory.c']]]
];
