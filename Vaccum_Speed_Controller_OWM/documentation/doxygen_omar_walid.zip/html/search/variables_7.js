var searchData=
[
  ['pointer_998',['pointer',['../struct_pointer_pair.html#ae6067d740982f25ff3cbd5ca68f0b0aa',1,'PointerPair']]]
];
