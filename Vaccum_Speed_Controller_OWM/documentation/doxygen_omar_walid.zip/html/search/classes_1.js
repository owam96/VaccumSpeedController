var searchData=
[
  ['pointerpair_876',['PointerPair',['../struct_pointer_pair.html',1,'']]]
];
